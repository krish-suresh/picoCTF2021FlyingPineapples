import textwrap
blocks = [1 , 3, 4, 5, 6,1 , 3, 4, 5, 6,1 , 3, 4, 5, 6,1 , 3, 4, 5, 6,1 , 3, 4, 5, 6,1 , 3, 4, 5, 6,]
randList = []
for i in range(264 + 1):
    y = ((((i+1) * 327) % 681 ) + 344) % 313
    randList.append(y)


seedList = []
for i in range(264+1):
    seedList.append(((i+1) * 127) % 500)
# print(seedList)

f = open("output.txt", "r")
blocks = []
for stringOfOutput in f:
    var = int(stringOfOutput)
    blockCount = 5
    # var = 879059547225600221
    seed=seedList[0]
    a = randList[0]^var
    funReturn = a^0
    binStr = str(bin(funReturn))
    bn = []
    for i,char in enumerate(binStr):
        if i%2==0:
            bn.append(binStr[i:i+2])
    bn.pop(0)
    # print(bn)
    raw = ['0' for i in range(blockCount*6)]
    xAssigned = []
    for i,a in enumerate(bn):
        x=0
        if i!=0:
            x = i*seed%(blockCount*6)
            while x in xAssigned:
                x = x - 1
            
        if a == "11":    
            raw[x] = "1"
        else:
            raw[x] = "0"
        xAssigned.append(x)
    rawBlock = ''.join(raw)
    blocks.append(textwrap.wrap(rawBlock, 6))
print(len(blocks))

inputFile = open("input.txt", "w")
for i in range(len(blocks[0])):
    line = ""
    for x in blocks:
        line += x[i]+" "
    line = line[:-1] + '\n'
    inputFile.write(line)